"use strict";
(() => {
  // src/lib/companion-response.ts
  function parseCompanionResponse(payload) {
    if (!payload || typeof payload !== "object") {
      return { ok: false, message: "Circles returned an invalid companion response." };
    }
    const response = payload;
    if (response.ok !== true) {
      return {
        ok: false,
        needsAuth: response.needsAuth,
        message: response.message ?? "Circles could not load the companion state."
      };
    }
    if (!response.appState || typeof response.appState !== "object") {
      return { ok: false, message: "Circles returned an invalid companion response." };
    }
    return response;
  }

  // src/content.ts
  var ORIGIN = window.location.origin;
  function extensionHeaders() {
    return {
      "X-Circles-Extension": "v1"
    };
  }
  function submitResult(data) {
    const record = data;
    const ok = record?.ok === true || record?.submit?.ok === true;
    return {
      ok,
      message: record?.submit?.message ?? record?.message ?? (ok ? "Saved." : "Failed.")
    };
  }
  async function getAppState() {
    try {
      const response = await fetch(`${ORIGIN}/api/ext/companion`, {
        signal: AbortSignal.timeout(15e3),
        headers: extensionHeaders(),
        credentials: "same-origin"
      });
      if (response.redirected && response.url.includes("/login")) {
        return { ok: false, needsAuth: true, message: "Log in to Circles first." };
      }
      if (!response.ok) {
        return { ok: false, message: `Circles returned ${response.status}.` };
      }
      return parseCompanionResponse(await response.json());
    } catch (error) {
      console.warn("[Circles Companion Bridge] Error connecting to Circles:", error);
      return { ok: false, message: "Could not reach Circles." };
    }
  }
  async function postJson(path, value) {
    try {
      const response = await fetch(`${ORIGIN}${path}`, {
        signal: AbortSignal.timeout(2e4),
        method: "POST",
        headers: {
          ...extensionHeaders(),
          "Content-Type": "application/json"
        },
        body: JSON.stringify(value),
        credentials: "same-origin"
      });
      if (response.redirected && response.url.includes("/login")) {
        return { ok: false, needsAuth: true, message: "Log in to Circles first." };
      }
      if (!response.ok) {
        const errJson = await response.json().catch(() => null);
        return { ok: false, message: errJson?.message ?? `Circles returned ${response.status}.` };
      }
      const data = await response.json().catch(() => null);
      const result = submitResult(data);
      return {
        ok: result.ok,
        message: result.message,
        submit: {
          ok: Boolean(data?.submit?.ok ?? result.ok),
          message: data?.submit?.message ?? result.message
        },
        captured: data?.captured,
        processedItems: data?.processedItems,
        newInteractions: data?.newInteractions,
        enrichedInteractions: data?.enrichedInteractions,
        newPeople: data?.newPeople,
        updatedPeople: data?.updatedPeople
      };
    } catch {
      return { ok: false, message: "Could not reach Circles." };
    }
  }
  async function handle(request) {
    switch (request.type) {
      case "BRIDGE_PING":
        return { ok: true };
      case "GET_APP_STATE":
        return getAppState();
      case "POST_CONNECT": {
        return postJson("/api/ext/connect", {
          sessionToken: request.sessionToken,
          publicationUrl: request.publicationUrl
        });
      }
      case "POST_INSTALL": {
        return postJson("/api/ext/install", {});
      }
      case "POST_ACTIVITY_BATCH": {
        const result = await postJson("/api/ext/activity", request.payload);
        if (result.ok) {
          window.dispatchEvent(new CustomEvent("circles:activity-captured"));
        }
        return result;
      }
      case "POST_CREATE_PERSON": {
        return postJson("/api/ext/person", {
          name: request.name,
          handle: request.handle,
          lists: request.lists,
          tags: request.tags
        });
      }
    }
  }
  chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    if (!["BRIDGE_PING", "GET_APP_STATE", "POST_CONNECT", "POST_INSTALL", "POST_ACTIVITY_BATCH", "POST_CREATE_PERSON"].includes(
      request?.type
    ))
      return;
    void handle(request).then(sendResponse).catch(() => sendResponse({ ok: false, message: "Circles bridge request failed." }));
    return true;
  });
  document.documentElement.dataset.circlesExtension = "v1";
  window.dispatchEvent(new CustomEvent("circles:extension-detected"));
  chrome.runtime.sendMessage({ type: "APP_PAGE_LOADED" }).catch(() => void 0);
  window.addEventListener("circles:connect-request", () => {
    void chrome.runtime.sendMessage({ type: "connect-from-app" }).catch(() => void 0);
  });
  window.addEventListener("circles:submit-publication", (event) => {
    const detail = event.detail;
    if (!detail?.flowId) return;
    void chrome.runtime.sendMessage({
      type: "SUBMIT_PUBLICATION_URL",
      flowId: detail.flowId,
      publicationUrl: detail.publicationUrl ?? null
    }).catch(() => void 0);
  });
  chrome.runtime.onMessage.addListener((message) => {
    const record = message;
    if (record.type === "FLOW_CHANGED") {
      window.dispatchEvent(new CustomEvent("circles:flow-changed", { detail: record.flow }));
    }
  });
})();
//# sourceMappingURL=content.js.map
