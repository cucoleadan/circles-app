"use strict";
(() => {
  // src/popup/popup.ts
  function byId(id) {
    return document.getElementById(id);
  }
  var substackDot = byId("substack-dot");
  var substackText = byId("substack-text");
  var appDot = byId("app-dot");
  var appText = byId("app-text");
  var connectBtn = byId("connect-btn");
  var flowText = byId("flow-text");
  var askSection = byId("ask-section");
  var pubInput = byId("pub-input");
  var pubError = byId("pub-error");
  var pubSkipBtn = byId("pub-skip-btn");
  var pubSubmitBtn = byId("pub-submit-btn");
  var profileLine = byId("profile-line");
  var handleInput = byId("handle-input");
  var listsContainer = byId("lists-container");
  var tagsInput = byId("tags-input");
  var addBtn = byId("add-btn");
  var actionText = byId("action-text");
  var extensionVersion = byId("extension-version");
  var openAppBtn = document.getElementById("open-app-btn");
  extensionVersion.textContent = `v${chrome.runtime.getManifest().version}`;
  openAppBtn?.addEventListener("click", () => {
    void chrome.tabs.create({ url: "https://circles.mhntwrkdan.dev" });
  });
  var profile = null;
  var lists = [];
  var flow = { phase: "idle" };
  var appPublicationUrl = null;
  var appConnectionState = "unreachable";
  async function send(request) {
    try {
      return await chrome.runtime.sendMessage(request);
    } catch {
      return { ok: false, message: "Extension restarted. Reopen the popup and retry." };
    }
  }
  function setDot(dot, state) {
    dot.className = `dot${state === "ok" ? " ok" : state === "bad" ? " bad" : state === "warn" ? " warn" : ""}`;
  }
  function flowLabel(state) {
    switch (state.phase) {
      case "waiting-substack-login":
        return "Waiting for you to log in on Substack\u2026";
      case "asking-publication":
        return "Add your publication URL to finish connecting.";
      case "sending":
        return "Encrypting and sending your session\u2026";
      case "done":
        return "Connected to Circles.";
      case "failed":
        return state.message;
      case "idle":
        return "";
    }
  }
  function flowHintClass(state) {
    if (state.phase === "done") return "ok";
    if (state.phase === "failed") return "bad";
    if (state.phase === "waiting-substack-login" || state.phase === "asking-publication" || state.phase === "sending") {
      return "warn";
    }
    return "";
  }
  var PUBLICATION_URL_PATTERN = /^https:\/\/(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\.substack\.com\/?$/i;
  function validPublicationUrl(value) {
    const clean = value.trim();
    return clean.length === 0 || PUBLICATION_URL_PATTERN.test(clean);
  }
  async function submitPublicationUrl(publicationUrl) {
    if (flow.phase !== "asking-publication") return;
    pubError.classList.add("hidden");
    await send({
      type: "SUBMIT_PUBLICATION_URL",
      flowId: flow.flowId,
      publicationUrl
    });
    pubInput.value = "";
  }
  function renderFlow() {
    flowText.textContent = flowLabel(flow);
    flowText.className = `hint ${flowHintClass(flow)}`;
    const busy = flow.phase === "waiting-substack-login" || flow.phase === "asking-publication" || flow.phase === "sending";
    const connected = appConnectionState === "connected";
    connectBtn.disabled = busy || connected;
    connectBtn.textContent = busy ? "Connecting\u2026" : connected ? "Substack account connected" : "Connect Substack account";
    askSection.classList.toggle("hidden", flow.phase !== "asking-publication");
    if (flow.phase === "asking-publication") {
      if (!pubInput.value && appPublicationUrl) {
        pubInput.value = appPublicationUrl;
      }
      pubInput.focus();
    }
  }
  function renderProfile() {
    if (profile) {
      profileLine.innerHTML = `Viewing <strong class="profile-badge">@${profile.handle}</strong>${profile.name ? ` <span class="profile-name">(${profile.name})</span>` : ""}`;
      handleInput.value = profile.handle;
      handleInput.disabled = true;
    } else {
      profileLine.textContent = "Browse to any Substack profile to auto-detect.";
      handleInput.value = "";
      handleInput.disabled = false;
    }
    updateAddButton();
  }
  function renderLists() {
    listsContainer.textContent = "";
    if (lists.length === 0) {
      const empty = document.createElement("div");
      empty.className = "list-empty";
      empty.textContent = "No custom lists yet. Create lists in Circles.";
      listsContainer.append(empty);
      return;
    }
    for (const list of lists) {
      const label = document.createElement("label");
      label.className = "list-item";
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.value = list.id;
      checkbox.addEventListener("change", updateAddButton);
      const name = document.createElement("span");
      name.textContent = list.name;
      label.append(checkbox, name);
      listsContainer.append(label);
    }
  }
  function updateAddButton() {
    const handle = handleInput.value.trim();
    const hasHandle = handle.length > 0;
    const checked = [...listsContainer.querySelectorAll("input:checked")];
    addBtn.disabled = !hasHandle;
    const labelText = checked.length === 0 ? "Add to Circles" : `Add to ${checked.length} list${checked.length === 1 ? "" : "s"}`;
    addBtn.innerHTML = `
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <line x1="12" y1="5" x2="12" y2="19"></line>
      <line x1="5" y1="12" x2="19" y2="12"></line>
    </svg>
    <span>${labelText}</span>
  `;
  }
  function selectedListIds() {
    return [...listsContainer.querySelectorAll("input:checked")].map(
      (checkbox) => checkbox.value
    );
  }
  function parseTags() {
    return tagsInput.value.split(",").map((tag) => tag.trim()).filter((tag) => tag.length > 0 && tag.length <= 32).slice(0, 8);
  }
  function renderAppStatus(state, profileName, userEmail = null) {
    switch (state) {
      case "connected":
        appText.textContent = userEmail ? `${userEmail}` : profileName ? `${profileName}` : "Connected";
        setDot(appDot, "ok");
        break;
      case "none":
        appText.textContent = "No Substack linked";
        setDot(appDot, "warn");
        break;
      case "needsAuth":
        appText.textContent = "Log in to Circles first";
        setDot(appDot, "bad");
        break;
      case "unreachable":
        appText.textContent = "Open Circles in a tab";
        setDot(appDot, "bad");
        break;
    }
  }
  async function refreshStatus() {
    const status = await send({ type: "GET_STATUS" });
    if (!status.ok) return;
    flow = status.flow ?? { phase: "idle" };
    appPublicationUrl = status.appPublicationUrl ?? null;
    setDot(substackDot, status.substackLoggedIn ? "ok" : "bad");
    substackText.textContent = status.substackLoggedIn ? "Logged in" : "Not logged in";
    appConnectionState = status.appState ?? "unreachable";
    renderAppStatus(appConnectionState, status.appProfile ?? null, status.appUserEmail ?? null);
    const profileResult = await send({ type: "GET_CURRENT_PROFILE" });
    profile = profileResult.profile ?? null;
    renderProfile();
    const listsResult = await send({ type: "FETCH_LISTS" });
    if (listsResult.ok) {
      lists = listsResult.lists ?? [];
    } else {
      lists = [];
      actionText.textContent = listsResult.message ?? "Could not load lists.";
      actionText.className = "action-feedback warn";
      if (listsResult.needsAuth) {
        profileLine.textContent = "Log in to Circles first, then reopen this popup.";
        profileLine.className = "profile-line hint bad";
      } else if (listsResult.message?.includes("Open")) {
        profileLine.textContent = "Open Circles in a tab to enable adding people.";
        profileLine.className = "profile-line hint warn";
      }
    }
    renderLists();
    renderFlow();
  }
  connectBtn.addEventListener("click", async () => {
    connectBtn.disabled = true;
    const result = await send({ type: "START_CONNECT_FLOW" });
    flow = result.flow ?? { phase: "idle" };
    renderFlow();
  });
  pubSubmitBtn.addEventListener("click", () => {
    const value = pubInput.value.trim();
    if (!validPublicationUrl(value)) {
      pubError.textContent = "Enter a valid https://\u2026substack.com URL or skip.";
      pubError.classList.remove("hidden");
      return;
    }
    void submitPublicationUrl(value || null);
  });
  pubSkipBtn.addEventListener("click", () => {
    void submitPublicationUrl(null);
  });
  pubInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      pubSubmitBtn.click();
    }
  });
  addBtn.addEventListener("click", async () => {
    const name = profile?.name ?? handleInput.value.trim();
    const handle = handleInput.value.trim();
    if (!handle) return;
    addBtn.disabled = true;
    actionText.className = "action-feedback hint warn";
    actionText.textContent = "Saving to Circles\u2026";
    const result = await send({
      type: "ADD_TO_LISTS",
      name,
      handle,
      lists: selectedListIds(),
      tags: parseTags()
    });
    const isOk = result.ok && result.submit?.ok !== false;
    actionText.textContent = isOk ? "\u2713 Saved to Circles CRM" : result.message ?? "Failed to save.";
    actionText.className = `action-feedback ${isOk ? "ok" : "bad"}`;
    addBtn.disabled = false;
    updateAddButton();
    if (isOk) {
      tagsInput.value = "";
      setTimeout(() => {
        actionText.textContent = "";
      }, 4e3);
    }
  });
  handleInput.addEventListener("input", updateAddButton);
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "FLOW_CHANGED" && message.flow) {
      flow = message.flow;
      renderFlow();
      if (flow.phase === "done") void refreshStatus();
    }
  });
  void refreshStatus();
})();
//# sourceMappingURL=popup.js.map
