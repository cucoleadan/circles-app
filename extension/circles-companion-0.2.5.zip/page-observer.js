"use strict";
(() => {
  // src/lib/conversation-capture.ts
  var record = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
  var text = (value, max) => typeof value === "string" && value.length <= max ? value : null;
  var id = (value) => typeof value === "string" && /^[0-9]+$/.test(value) && value.length <= 512 || typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? String(value) : null;
  function safeUrl(value) {
    try {
      const url = new URL(String(value));
      return url.protocol === "https:" && !url.username && !url.password ? url.href : null;
    } catch {
      return null;
    }
  }
  function conversationTarget(url) {
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "https:" || parsed.username || parsed.password || !(parsed.hostname === "substack.com" || parsed.hostname.endsWith(".substack.com"))) return null;
      const note = /^\/api\/v1\/reader\/comment\/(\d+)\/replies$/.exec(parsed.pathname);
      const post = /^\/api\/v1\/post\/(\d+)\/comments$/.exec(parsed.pathname);
      if (!note && !post) return null;
      return { targetType: note ? "note" : "post", targetId: (note ?? post)[1], sourceUrl: parsed.origin + parsed.pathname };
    } catch {
      return null;
    }
  }
  function normalizeConversationResponse(url, payload) {
    const target = conversationTarget(url);
    const data = record(payload);
    if (!target || !data) return null;
    const branches = target.targetType === "note" ? data.commentBranches ?? data.comments : data.comments;
    if (!Array.isArray(branches)) return null;
    let count = 0;
    function reply(value, depth) {
      const branch = record(value);
      const comment = record(branch?.comment) ?? branch;
      if (!comment || !id(comment.id) || typeof comment.body !== "string") throw new Error("Unsupported conversation comment shape.");
      if (++count > 1e3 || depth > 20 || comment.body.length > 1e5) throw new Error("Conversation exceeds capture safety limits; no partial tree was queued.");
      const user = record(comment.user) ?? record(comment.author) ?? record(branch?.user);
      const children = branch?.children ?? branch?.descendantComments ?? branch?.replies ?? [];
      if (!Array.isArray(children)) throw new Error("Invalid conversation children.");
      return {
        id: id(comment.id),
        body: comment.body,
        createdAt: text(comment.createdAt ?? comment.date ?? comment.created_at, 128),
        authorName: text(comment.authorName ?? comment.name ?? user?.name, 256),
        authorHandle: text(comment.authorHandle ?? comment.handle ?? user?.handle, 256),
        authorPhotoUrl: safeUrl(comment.authorPhotoUrl ?? comment.photo_url ?? comment.photoUrl ?? user?.photo_url ?? user?.photoUrl),
        authorId: id(comment.authorId ?? user?.id ?? comment.user_id),
        children: children.map((child) => reply(child, depth + 1))
      };
    }
    const comments = branches.map((branch) => reply(branch, 0));
    let rootAuthor = null;
    const root = record(data.rootComment ?? data.rootAuthor);
    if (root && typeof root.body === "string") rootAuthor = reply({ ...root, children: [] }, 0);
    const more = data.moreBranches ?? data.moreComments ?? 0;
    if (typeof more !== "number" || !Number.isSafeInteger(more) || more < 0) throw new Error("Invalid conversation pagination.");
    return { kind: "conversation", ...target, comments, rootAuthor, moreComments: more, nextCursor: text(data.nextCursor, 2048) };
  }

  // src/lib/activity-pagination.ts
  function activityPageEvidence(url, payload) {
    let request;
    try {
      request = new URL(url);
    } catch {
      return null;
    }
    if (request.origin !== "https://substack.com" || request.pathname !== "/api/v1/activity-feed-web") return null;
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) return null;
    const page = payload;
    if (!Array.isArray(page.activityItems)) return null;
    const date = (value) => typeof value === "string" && /^\d{4}-\d{2}-\d{2}T/.test(value) && Number.isFinite(Date.parse(value)) ? new Date(value).toISOString() : null;
    const last = page.activityItems.at(-1);
    const item = last && typeof last === "object" && !Array.isArray(last) ? last : {};
    return {
      after: date(request.searchParams.get("after")),
      more: typeof page.more === "boolean" ? page.more : null,
      count: page.activityItems.length,
      lastCreatedAt: date(item.created_at),
      lastUpdatedAt: date(item.updated_at)
    };
  }

  // src/lib/outbound-action.ts
  var record2 = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
  function requestBody(value) {
    if (typeof value === "string") {
      try {
        return record2(JSON.parse(value)) ?? {};
      } catch {
        return Object.fromEntries(new URLSearchParams(value));
      }
    }
    if (typeof FormData !== "undefined" && value instanceof FormData) {
      return Object.fromEntries(value.entries());
    }
    return record2(value) ?? {};
  }
  function responseId(value) {
    const data = record2(value);
    const candidate = data?.id ?? data?.comment?.id ?? data?.item?.comment?.id;
    return typeof candidate === "number" || typeof candidate === "string" && candidate ? String(candidate) : null;
  }
  function textFromBodyJson(value) {
    const texts = [];
    const visit = (node) => {
      if (typeof node === "string") return;
      if (Array.isArray(node)) return node.forEach(visit);
      const item = record2(node);
      if (!item) return;
      if (item.type === "text" && typeof item.text === "string") texts.push(item.text);
      visit(item.content);
    };
    visit(value);
    const result = texts.join(" ").trim();
    return result || null;
  }
  function pageAuthor(pageUrl) {
    try {
      const match = /^\/@([^/]+)/.exec(new URL(pageUrl).pathname);
      return match?.[1] ? { handle: decodeURIComponent(match[1]), name: null } : null;
    } catch {
      return null;
    }
  }
  function responseAuthor(value) {
    const data = record2(value);
    if (!data) return null;
    const candidates = [
      data.user,
      data.author,
      record2(data.comment)?.user,
      record2(data.comment)?.author,
      record2(record2(data.item)?.comment)?.user,
      record2(data.post)?.user,
      record2(data.post)?.author
    ];
    for (const candidate of candidates) {
      const person = record2(candidate);
      const handle = person?.handle ?? person?.username;
      if (typeof handle === "string" && handle.trim()) {
        return {
          handle: handle.trim().replace(/^@/, ""),
          name: typeof person?.name === "string" ? person.name : null
        };
      }
    }
    return null;
  }
  function captureOutboundAction(input) {
    let request;
    try {
      request = new URL(input.requestUrl, input.pageUrl);
    } catch {
      return null;
    }
    if (request.protocol !== "https:" || !(request.hostname === "substack.com" || request.hostname.endsWith(".substack.com"))) return null;
    const method = input.method.toUpperCase();
    if (!["POST", "PUT", "PATCH", "DELETE"].includes(method)) return null;
    const data = requestBody(input.body);
    const occurredAt = input.occurredAt ?? (/* @__PURE__ */ new Date()).toISOString();
    const targetAuthor = responseAuthor(input.response) ?? pageAuthor(input.pageUrl);
    const targetUrl = input.pageUrl;
    const reaction = /^\/api\/v1\/(comment|post)\/(\d+)\/reaction$/.exec(request.pathname);
    if (reaction) {
      const targetKind = reaction[1] === "post" ? "post" : "comment";
      const targetId = reaction[2];
      return {
        kind: "outbound-action",
        action: "like",
        active: method !== "DELETE",
        externalId: `outbound:like:${targetKind}:${targetId}`,
        occurredAt,
        targetKind,
        targetId,
        targetUrl,
        targetAuthor,
        body: null
      };
    }
    if (request.pathname === "/api/v1/restack/feed") {
      const targetId = data.commentId ?? data.comment_id ?? data.postId ?? data.post_id;
      if (targetId === void 0 || targetId === null) return null;
      const targetKind = data.postId || data.post_id ? "post" : "note";
      return {
        kind: "outbound-action",
        action: "restack",
        active: method !== "DELETE",
        externalId: `outbound:restack:${targetKind}:${targetId}`,
        occurredAt,
        targetKind,
        targetId: String(targetId),
        targetUrl,
        targetAuthor,
        body: textFromBodyJson(data.bodyJson ?? data.body_json)
      };
    }
    if (request.pathname === "/api/v1/comment/feed" && method === "POST") {
      const parentId = data.parent_id ?? data.parentId;
      if (parentId === void 0 || parentId === null) return null;
      const id2 = responseId(input.response);
      return {
        kind: "outbound-action",
        action: "reply",
        active: true,
        externalId: id2 ? `comment-${id2}` : `outbound:reply:${parentId}:${occurredAt}`,
        occurredAt,
        targetKind: "comment",
        targetId: String(parentId),
        targetUrl,
        targetAuthor,
        body: textFromBodyJson(data.bodyJson ?? data.body_json) ?? (typeof data.body === "string" ? data.body : null)
      };
    }
    const postComment = /^\/api\/v1\/post\/(\d+)\/comments?$/.exec(request.pathname);
    if (postComment && method === "POST") {
      const id2 = responseId(input.response);
      const targetId = postComment[1];
      return {
        kind: "outbound-action",
        action: "comment",
        active: true,
        externalId: id2 ? `comment-${id2}` : `outbound:comment:post:${targetId}:${occurredAt}`,
        occurredAt,
        targetKind: "post",
        targetId,
        targetUrl,
        targetAuthor,
        body: textFromBodyJson(data.bodyJson ?? data.body_json) ?? (typeof data.body === "string" ? data.body : null)
      };
    }
    const deletedComment = /^\/api\/v1\/comment\/(\d+)$/.exec(request.pathname);
    if (deletedComment && method === "DELETE") {
      return {
        kind: "outbound-action",
        action: "comment",
        active: false,
        externalId: `comment-${deletedComment[1]}`,
        occurredAt,
        targetKind: "comment",
        targetId: deletedComment[1],
        targetUrl,
        targetAuthor,
        body: null
      };
    }
    return null;
  }

  // src/page-observer.ts
  var ACTIVITY_PATH = "/api/v1/activity-feed-web";
  var MESSAGE_SOURCE = "circles-page-observer";
  var MAX_CAPTURE_BYTES = 2e6;
  function isActivityResponse(url) {
    try {
      const parsed = new URL(url, window.location.href);
      return parsed.protocol === "https:" && (parsed.hostname === "substack.com" || parsed.hostname.endsWith(".substack.com")) && parsed.pathname === ACTIVITY_PATH;
    } catch {
      return false;
    }
  }
  function publishPayload(payload, transport, url) {
    try {
      const conversation = normalizeConversationResponse(new URL(url, window.location.href).href, payload);
      if (conversation) {
        if (new TextEncoder().encode(JSON.stringify(conversation)).length > MAX_CAPTURE_BYTES) throw new Error("Conversation exceeds upload size limit.");
        console.log(`[Circles Activity] Captured ${conversation.targetType} conversation from an existing ${transport} response; ${conversation.moreComments} more comments reported.`);
        window.postMessage({ source: MESSAGE_SOURCE, type: "CONVERSATION_RESPONSE", payload: conversation }, window.location.origin);
        return;
      }
      if (conversationTarget(new URL(url, window.location.href).href)) {
        console.warn("[Circles Activity] Unsupported response shape; conversation was not queued.");
        return;
      }
      const serialized = JSON.stringify(payload);
      if (serialized.length === 0 || serialized.length > MAX_CAPTURE_BYTES) {
        console.warn("[Circles Activity] Ignored an empty or oversized activity response.");
        return;
      }
      const record3 = payload;
      if (!record3 || !Array.isArray(record3.activityItems)) return;
      console.log(
        `[Circles Activity] Detected ${record3.activityItems.length} activity items from an existing Substack ${transport} response.`
      );
      const evidence = activityPageEvidence(new URL(url, window.location.href).href, payload);
      if (evidence) console.log("[Circles Activity] Pagination evidence (no extra requests):", evidence);
      window.postMessage(
        { source: MESSAGE_SOURCE, type: "ACTIVITY_RESPONSE", payload },
        window.location.origin
      );
    } catch (error) {
      console.warn("[Circles Activity] Response could not be captured completely.", error);
    }
  }
  function observeResponse(response) {
    if (!response.ok || !(isActivityResponse(response.url) || conversationTarget(response.url))) return;
    void response.clone().json().then((payload) => publishPayload(payload, "fetch", response.url)).catch(() => {
      console.warn("[Circles Activity] Could not read the observed Substack activity response.");
    });
  }
  function publishOutboundAction(input) {
    try {
      const action = captureOutboundAction(input);
      if (!action) return;
      console.log(
        `[Circles Activity] Captured outbound ${action.active ? action.action : `removed ${action.action}`} for ${action.targetKind} ${action.targetId}.`
      );
      window.postMessage(
        { source: MESSAGE_SOURCE, type: "OUTBOUND_ACTION", payload: action },
        window.location.origin
      );
    } catch (error) {
      console.warn("[Circles Activity] Outbound action could not be captured.", error);
    }
  }
  var originalFetch = window.fetch;
  window.fetch = async function circlesObservedFetch(...args) {
    const [input, init] = args;
    const requestUrl = typeof input === "string" || input instanceof URL ? String(input) : input.url;
    const method = init?.method ?? (input instanceof Request ? input.method : "GET");
    const bodyPromise = init?.body !== void 0 ? Promise.resolve(init.body) : input instanceof Request && !["GET", "HEAD"].includes(method.toUpperCase()) ? input.clone().text().catch(() => void 0) : Promise.resolve(void 0);
    const response = await originalFetch.apply(this, args);
    observeResponse(response);
    if (response.ok) {
      const [body, responsePayload] = await Promise.all([
        bodyPromise,
        response.clone().json().catch(() => void 0)
      ]);
      publishOutboundAction({
        requestUrl,
        method,
        body,
        response: responsePayload,
        pageUrl: window.location.href
      });
    }
    return response;
  };
  var originalOpen = XMLHttpRequest.prototype.open;
  var originalSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function circlesObservedOpen(method, url, asyncFlag = true, username, password) {
    Object.defineProperty(this, "__circlesActivityUrl", {
      configurable: true,
      value: String(url)
    });
    Object.defineProperty(this, "__circlesActivityMethod", {
      configurable: true,
      value: method
    });
    return originalOpen.call(this, method, url, asyncFlag, username, password);
  };
  XMLHttpRequest.prototype.send = function circlesObservedSend(body) {
    this.addEventListener("load", () => {
      const observed = this;
      const url = observed.__circlesActivityUrl;
      if (!url || this.status < 200 || this.status >= 300) return;
      try {
        const responsePayload = this.responseType === "json" ? this.response : JSON.parse(this.responseText);
        if (isActivityResponse(url) || conversationTarget(new URL(url, window.location.href).href)) {
          publishPayload(responsePayload, "xhr", url);
        }
        publishOutboundAction({
          requestUrl: url,
          method: observed.__circlesActivityMethod ?? "GET",
          body,
          response: responsePayload,
          pageUrl: window.location.href
        });
      } catch {
        publishOutboundAction({
          requestUrl: url,
          method: observed.__circlesActivityMethod ?? "GET",
          body,
          pageUrl: window.location.href
        });
      }
    }, { once: true });
    return originalSend.call(this, body);
  };
  console.log("[Circles Activity] Passive observer installed; no extra Substack requests will be made.");
})();
