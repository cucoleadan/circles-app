// src/lib/constants.ts
var APP_ORIGINS = [
  "https://circles.mhntwrkdan.dev",
  "http://localhost:4321",
  "http://127.0.0.1:4321"
];
var APP_ORIGIN = APP_ORIGINS[0];
var CONNECT_FLOW_TIMEOUT_MS = 5 * 6e4;
var CONNECT_POLL_INTERVAL_MS = 1e3;
var AUTO_CONNECT_COOLDOWN_MS = 30 * 6e4;
var SUBSTACK_SESSION_COOKIE = "substack.sid";

// src/lib/cookies.ts
function isSubstackCookie(cookie) {
  const host = cookie.domain.startsWith(".") ? cookie.domain.slice(1) : cookie.domain;
  return host === "substack.com" || host.endsWith(".substack.com");
}
function substackCookies() {
  return chrome.cookies.getAll({}).then((all) => all.filter(isSubstackCookie));
}
async function getSubstackSessionValue() {
  const cookies = await substackCookies();
  const sid = cookies.find((cookie) => cookie.name === SUBSTACK_SESSION_COOKIE);
  return sid && sid.value.length > 0 ? sid.value : null;
}
async function hasSubstackSession() {
  return await getSubstackSessionValue() !== null;
}

// src/lib/detect.ts
function detectProfileFromTab(tab) {
  const url = tab.url ?? "";
  const pathname = (() => {
    try {
      return new URL(url).pathname;
    } catch {
      return "";
    }
  })();
  const handleMatch = pathname.match(
    /^\/(?:@([^/?#]+)|profile\/\d+-([^/?#]+))(?:\/.*)?$/
  );
  const handle = handleMatch?.[1] ?? handleMatch?.[2];
  if (!handle) return null;
  let name = null;
  const title = (tab.title ?? "").replace(/\s*-\s*Substack\s*$/i, "").trim();
  if (title && !title.includes("@") && title.length <= 80) {
    name = title;
  }
  return { handle: handle.toLocaleLowerCase("en"), name, pageUrl: url };
}

// src/lib/app-bridge.ts
function isAppOriginUrl(url) {
  try {
    return !!url && APP_ORIGINS.some((origin) => new URL(url).origin === origin);
  } catch {
    return false;
  }
}
async function send(tabId, request, timeout = 2e4) {
  let timer;
  try {
    const response = await Promise.race([
      chrome.tabs.sendMessage(tabId, request),
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error("Bridge timeout")), timeout);
      })
    ]);
    if (!response || typeof response.ok !== "boolean") {
      throw new Error("Invalid bridge response");
    }
    return response;
  } finally {
    clearTimeout(timer);
  }
}
async function requestViaBridge(request, open = false) {
  try {
    let tabs = (await chrome.tabs.query({ url: APP_ORIGINS.map((origin2) => `${origin2}/*`) })).filter((tab) => tab.id !== void 0 && isAppOriginUrl(tab.url)).sort((a, b) => Number(b.active) - Number(a.active));
    const origin = tabs[0]?.url ? new URL(tabs[0].url).origin : APP_ORIGIN;
    tabs = tabs.filter((tab) => new URL(tab.url).origin === origin);
    if (!tabs.length && open) {
      tabs = [await chrome.tabs.create({ url: `${origin}`, active: true })];
    }
    if (!tabs.length) {
      return { ok: false, message: "Open Circles in a browser tab first." };
    }
    const deadline = Date.now() + 6e3;
    do {
      for (const tab of tabs) {
        let ready = false;
        try {
          ready = (await send(tab.id, { type: "BRIDGE_PING" }, 750)).ok;
        } catch {
        }
        if (ready) {
          try {
            return await send(tab.id, request);
          } catch {
            return { ok: false, message: "Circles did not confirm the request. Check the app before retrying." };
          }
        }
      }
      await new Promise((resolve) => setTimeout(resolve, 250));
    } while (Date.now() < deadline);
    return { ok: false, message: "Reload your Circles tab once to activate the companion bridge." };
  } catch {
    return { ok: false, message: "Could not reach the Circles app tab." };
  }
}
var requestConnectBridge = (request) => requestViaBridge(request, true);

// src/lib/connection-status.ts
function recoveredFlow(flow2, connected, running) {
  if (running || !connected) return flow2;
  if (flow2.phase === "done") return { phase: "idle" };
  if (flow2.phase === "failed" && /Reload (?:your )?Circles|Open Circles|Could not reach Circles|Circles did not confirm|Connection was interrupted/.test(flow2.message)) {
    return { phase: "idle" };
  }
  return flow2;
}

// src/lib/conversation-capture.ts
var record = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
var text = (value, max) => typeof value === "string" && value.length <= max ? value : null;
var id = (value) => typeof value === "string" && /^[0-9]+$/.test(value) && value.length <= 512 || typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? String(value) : null;
function safeUrl(value) {
  try {
    const url = new URL(String(value));
    return url.protocol === "https:" && !url.username && !url.password ? url.href : null;
  } catch {
    return null;
  }
}
function conversationTarget(url) {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:" || parsed.username || parsed.password || !(parsed.hostname === "substack.com" || parsed.hostname.endsWith(".substack.com"))) return null;
    const note = /^\/api\/v1\/reader\/comment\/(\d+)\/replies$/.exec(parsed.pathname);
    const post = /^\/api\/v1\/post\/(\d+)\/comments$/.exec(parsed.pathname);
    if (!note && !post) return null;
    return { targetType: note ? "note" : "post", targetId: (note ?? post)[1], sourceUrl: parsed.origin + parsed.pathname };
  } catch {
    return null;
  }
}
function normalizeConversationResponse(url, payload) {
  const target = conversationTarget(url);
  const data = record(payload);
  if (!target || !data) return null;
  const branches = target.targetType === "note" ? data.commentBranches ?? data.comments : data.comments;
  if (!Array.isArray(branches)) return null;
  let count = 0;
  function reply(value, depth) {
    const branch = record(value);
    const comment = record(branch?.comment) ?? branch;
    if (!comment || !id(comment.id) || typeof comment.body !== "string") throw new Error("Unsupported conversation comment shape.");
    if (++count > 1e3 || depth > 20 || comment.body.length > 1e5) throw new Error("Conversation exceeds capture safety limits; no partial tree was queued.");
    const user = record(comment.user) ?? record(comment.author) ?? record(branch?.user);
    const children = branch?.children ?? branch?.descendantComments ?? branch?.replies ?? [];
    if (!Array.isArray(children)) throw new Error("Invalid conversation children.");
    return {
      id: id(comment.id),
      body: comment.body,
      createdAt: text(comment.createdAt ?? comment.date ?? comment.created_at, 128),
      authorName: text(comment.authorName ?? comment.name ?? user?.name, 256),
      authorHandle: text(comment.authorHandle ?? comment.handle ?? user?.handle, 256),
      authorPhotoUrl: safeUrl(comment.authorPhotoUrl ?? comment.photo_url ?? comment.photoUrl ?? user?.photo_url ?? user?.photoUrl),
      authorId: id(comment.authorId ?? user?.id ?? comment.user_id),
      children: children.map((child) => reply(child, depth + 1))
    };
  }
  const comments = branches.map((branch) => reply(branch, 0));
  let rootAuthor = null;
  const root = record(data.rootComment ?? data.rootAuthor);
  if (root && typeof root.body === "string") rootAuthor = reply({ ...root, children: [] }, 0);
  const more = data.moreBranches ?? data.moreComments ?? 0;
  if (typeof more !== "number" || !Number.isSafeInteger(more) || more < 0) throw new Error("Invalid conversation pagination.");
  return { kind: "conversation", ...target, comments, rootAuthor, moreComments: more, nextCursor: text(data.nextCursor, 2048) };
}
function validateCapturedConversation(value) {
  const data = record(value);
  if (data?.kind !== "conversation" || typeof data.sourceUrl !== "string") throw new Error("Invalid conversation capture.");
  const normalized = normalizeConversationResponse(data.sourceUrl, data);
  if (!normalized || normalized.targetId !== data.targetId || normalized.targetType !== data.targetType) throw new Error("Invalid conversation target.");
  return normalized;
}

// src/lib/activity-queue.ts
var KEY = "pendingActivityV1";
var CONNECTION_KEY = "activityConnectionId";
var ACTIVITY_RETRY_ALARM = "retry-captured-activity";
var serial = Promise.resolve();
function exclusive(work) {
  const result = serial.then(work);
  serial = result.catch(() => void 0);
  return result;
}
async function read() {
  const stored = await chrome.storage.local.get(KEY);
  return stored[KEY] ?? { batches: [], delivered: [] };
}
function validateOutboundAction(value) {
  const item = value;
  const actions = /* @__PURE__ */ new Set(["like", "restack", "comment", "reply"]);
  const targetKinds = /* @__PURE__ */ new Set(["note", "post", "comment"]);
  if (item?.kind !== "outbound-action" || !actions.has(String(item.action)) || typeof item.active !== "boolean" || typeof item.externalId !== "string" || item.externalId.length > 500 || typeof item.targetId !== "string" || item.targetId.length > 500 || !targetKinds.has(String(item.targetKind)) || typeof item.targetUrl !== "string" || item.targetUrl.length > 2e3 || typeof item.occurredAt !== "string" || !Number.isFinite(Date.parse(item.occurredAt))) return null;
  if (item.targetAuthor !== null && (typeof item.targetAuthor !== "object" || typeof item.targetAuthor.handle !== "string" || item.targetAuthor.handle.length > 200 || item.targetAuthor.name !== null && typeof item.targetAuthor.name !== "string")) return null;
  if (item.body !== null && (typeof item.body !== "string" || item.body.length > 1e5)) return null;
  return item;
}
async function rememberActivityConnection(response) {
  if (response.ok && response.appState?.connection) {
    await chrome.storage.local.set({ [CONNECTION_KEY]: response.appState.connection.id });
  }
}
function enqueueActivity(payload) {
  return exclusive(async () => {
    const items = payload?.activityItems;
    const conversation = payload?.kind === "conversation" ? validateCapturedConversation(payload) : null;
    const outboundAction = payload?.kind === "outbound-action" ? validateOutboundAction(payload) : null;
    if (!conversation && !outboundAction && !Array.isArray(items)) return { ok: false, message: "Invalid capture batch." };
    if (conversation) payload = conversation;
    if (outboundAction) payload = outboundAction;
    const captured = conversation ? conversation.comments.length : outboundAction ? 1 : items.length;
    const serialized = JSON.stringify(payload);
    if (new TextEncoder().encode(serialized).length > 2e6) return { ok: false, message: "Activity batch exceeds capture size limit." };
    const stored = await chrome.storage.local.get(CONNECTION_KEY);
    const connectionId = stored[CONNECTION_KEY];
    if (!connectionId) return { ok: false, message: "Open your connected Circles app once to enable durable capture." };
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(connectionId + serialized));
    const id2 = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
    const state = await read();
    if (state.delivered.includes(id2)) return { ok: true, captured };
    if (!state.batches.some((batch) => batch.id === id2)) {
      state.batches.push({ id: id2, connectionId, payload, attempts: 0, retryAt: 0 });
      if (state.batches.length > 100 || new TextEncoder().encode(JSON.stringify(state)).length > 4e6) {
        console.warn("[Circles Activity] Queue full; existing pending data preserved.");
        return { ok: false, message: "Capture queue full. Open Circles to deliver pending data." };
      }
      await chrome.storage.local.set({ [KEY]: state });
    }
    return { ok: true, queued: true, pendingBatches: state.batches.length, captured };
  });
}
function drainActivity(bridge) {
  return exclusive(async () => {
    const state = await read();
    if (!state.batches.some((batch) => batch.retryAt <= Date.now())) return;
    const app = await bridge({ type: "GET_APP_STATE" });
    const connection = app.ok ? app.appState?.connection : null;
    if (!connection) return;
    await rememberActivityConnection(app);
    const due = state.batches.filter((batch) => batch.connectionId === connection.id && batch.retryAt <= Date.now()).slice(0, 5);
    for (const batch of due) {
      const result = await bridge({ type: "POST_ACTIVITY_BATCH", payload: { ...batch.payload, expectedConnectionId: batch.connectionId } }).catch(() => ({ ok: false }));
      if (result.ok) {
        state.batches = state.batches.filter((pending) => pending.id !== batch.id);
        state.delivered = [...state.delivered, batch.id].slice(-100);
        console.log(`[Circles Activity] Delivered queued batch: ${result.captured ?? 0} items; ${result.newInteractions ?? 0} new interactions, ${result.enrichedInteractions ?? 0} enriched, ${result.newPeople ?? 0} new people; ${state.batches.length} pending.`);
      } else {
        batch.attempts++;
        batch.retryAt = Date.now() + Math.min(30, 2 ** Math.min(batch.attempts, 5)) * 6e4;
        console.warn("[Circles Activity] Delivery failed; batch retained for paced retry.");
      }
      await chrome.storage.local.set({ [KEY]: state });
      if (!result.ok) break;
    }
  });
}

// src/background.ts
var flow = { phase: "idle" };
var pendingPublicationUrl = null;
var crmHandles = null;
var crmMembers = null;
var appStateRequest = null;
var connectRequest = null;
var PUBLICATION_ASK_TIMEOUT_MS = 12e4;
var APP_STATE_CACHE_KEY = "appStateCache";
var APP_STATE_SUCCESS_TTL_MS = 3e4;
var APP_STATE_ERROR_TTL_MS = 0;
function populateMemberCache(state) {
  if (!state.ok || !state.appState) return;
  const handles = /* @__PURE__ */ new Set();
  const members = /* @__PURE__ */ new Map();
  for (const handle of state.appState.handles ?? []) {
    handles.add(handle.toLocaleLowerCase("en"));
  }
  for (const member of state.appState.members ?? []) {
    const key = member.handle.toLocaleLowerCase("en");
    handles.add(key);
    members.set(key, { name: member.name, lists: member.lists ?? [] });
  }
  crmHandles = handles;
  crmMembers = members;
}
function handlesFromAppState(state) {
  if (!state.ok || !state.appState) return null;
  populateMemberCache(state);
  return crmHandles;
}
async function waitForPublicationUrl(flowId) {
  const deadline = Date.now() + PUBLICATION_ASK_TIMEOUT_MS;
  while (Date.now() < deadline) {
    if (pendingPublicationUrl && pendingPublicationUrl.flowId === flowId) {
      const { url } = pendingPublicationUrl;
      pendingPublicationUrl = null;
      return url;
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  pendingPublicationUrl = null;
  return null;
}
async function readStoredFlow() {
  const stored = await chrome.storage.session.get("flow");
  if (stored.flow && typeof stored.flow === "object") {
    flow = stored.flow;
    if (["waiting-substack-login", "asking-publication", "sending"].includes(flow.phase)) {
      await setFlow({ phase: "failed", flowId: "interrupted", message: "Connection was interrupted. Click Connect to retry." });
    }
  }
}
async function setFlow(next) {
  flow = next;
  await chrome.storage.session.set({ flow: next });
  void chrome.runtime.sendMessage({ type: "FLOW_CHANGED", flow: next }).catch(() => void 0);
  void chrome.tabs.query({ url: APP_ORIGINS.map((origin) => `${origin}/*`) }).then((tabs) => {
    for (const tab of tabs) if (tab.id && isAppOriginUrl(tab.url)) {
      void chrome.tabs.sendMessage(tab.id, { type: "FLOW_CHANGED", flow: next }).catch(() => void 0);
    }
  }).catch(() => void 0);
  return next;
}
function isSubstackPageUrl(url) {
  if (!url) return false;
  try {
    const parsed = new URL(url);
    return parsed.protocol === "https:" && (parsed.hostname === "substack.com" || parsed.hostname.endsWith(".substack.com"));
  } catch {
    return false;
  }
}
async function requestAppState(force = false) {
  if (appStateRequest) return appStateRequest;
  appStateRequest = (async () => {
    if (!force) {
      const stored = await chrome.storage.session.get(APP_STATE_CACHE_KEY);
      const cached = stored[APP_STATE_CACHE_KEY];
      if (cached?.expiresAt && cached.expiresAt > Date.now()) {
        await rememberActivityConnection(cached.response);
        return cached.response;
      }
    }
    const response = await requestViaBridge({ type: "GET_APP_STATE" });
    await rememberActivityConnection(response);
    const ttl = response.ok && response.appState ? APP_STATE_SUCCESS_TTL_MS : APP_STATE_ERROR_TTL_MS;
    await chrome.storage.session.set({
      [APP_STATE_CACHE_KEY]: { response, expiresAt: Date.now() + ttl }
    });
    return response;
  })();
  try {
    return await appStateRequest;
  } finally {
    appStateRequest = null;
  }
}
async function clearAppStateCache() {
  crmHandles = null;
  crmMembers = null;
  await chrome.storage.session.remove(APP_STATE_CACHE_KEY);
}
async function rememberCrmHandle(handle, name, listIds) {
  const normalized = handle.toLocaleLowerCase("en");
  crmHandles?.add(normalized);
  const stored = await chrome.storage.session.get(APP_STATE_CACHE_KEY);
  const cached = stored[APP_STATE_CACHE_KEY];
  const appState = cached?.response.appState;
  const allLists = appState?.lists ?? [];
  const assignedLists = listIds ? allLists.filter((list) => listIds.includes(list.id)) : [];
  const existingMember = crmMembers?.get(normalized);
  const updatedLists = [
    ...existingMember?.lists ?? [],
    ...assignedLists.filter(
      (assigned) => !(existingMember?.lists ?? []).some((item) => item.id === assigned.id)
    )
  ];
  if (!crmMembers) crmMembers = /* @__PURE__ */ new Map();
  crmMembers.set(normalized, {
    name: name ?? existingMember?.name ?? normalized,
    lists: updatedLists
  });
  if (!appState) return;
  const handles = new Set(appState.handles ?? []);
  handles.add(normalized);
  const members = [...(appState.members ?? []).filter((m) => m.handle.toLocaleLowerCase("en") !== normalized)];
  members.push({
    handle: normalized,
    name: name ?? existingMember?.name ?? normalized,
    lists: updatedLists
  });
  await chrome.storage.session.set({
    [APP_STATE_CACHE_KEY]: {
      ...cached,
      response: {
        ...cached.response,
        appState: { ...appState, handles: [...handles], members }
      }
    }
  });
}
async function openOrFocusSubstackTab(focus) {
  const existing = await chrome.tabs.query({ url: "https://*.substack.com/*" });
  const candidate = existing[0];
  if (candidate?.id) {
    if (focus) {
      await chrome.tabs.update(candidate.id, { active: true });
    }
    return candidate;
  }
  return chrome.tabs.create({
    url: "https://substack.com/signin",
    ...focus ? {} : { active: false }
  });
}
async function waitForSubstackSession() {
  const deadline = Date.now() + CONNECT_FLOW_TIMEOUT_MS;
  while (Date.now() < deadline) {
    if (await hasSubstackSession()) return true;
    await new Promise((resolve) => setTimeout(resolve, CONNECT_POLL_INTERVAL_MS));
  }
  return false;
}
async function runConnectFlow(options) {
  if (connectRequest) return connectRequest;
  connectRequest = performConnectFlow(options).catch(() => setFlow({ phase: "failed", flowId: "failed", message: "Connection failed. Please retry." }));
  try {
    return await connectRequest;
  } finally {
    connectRequest = null;
  }
}
async function performConnectFlow(options) {
  if (flow.phase === "waiting-substack-login" || flow.phase === "asking-publication" || flow.phase === "sending") {
    return flow;
  }
  const flowId = crypto.randomUUID();
  const startedAt = Date.now();
  const state = await requestConnectBridge({ type: "GET_APP_STATE" });
  if (!state.ok) {
    return setFlow({
      phase: "failed",
      flowId,
      message: state.needsAuth ? "Log in to Circles first." : state.message ?? "Could not connect to Circles."
    });
  }
  let publicationUrl = null;
  if (options?.askPublication !== false) {
    await setFlow({ phase: "asking-publication", flowId, startedAt });
    publicationUrl = await waitForPublicationUrl(flowId);
  }
  await setFlow({ phase: "waiting-substack-login", flowId, startedAt });
  await openOrFocusSubstackTab(options?.focusSubstack ?? true);
  if (!await waitForSubstackSession()) {
    return setFlow({
      phase: "failed",
      flowId,
      message: "Timed out waiting for a Substack login. Log in and try again."
    });
  }
  const credential = await getSubstackSessionValue();
  if (!credential) {
    return setFlow({
      phase: "failed",
      flowId,
      message: "Could not read the Substack session cookie. Log in again and retry."
    });
  }
  await setFlow({ phase: "sending", flowId });
  const result = await requestConnectBridge({
    type: "POST_CONNECT",
    sessionToken: credential,
    publicationUrl
  });
  if (!result.ok || result.submit?.ok === false) {
    return setFlow({
      phase: "failed",
      flowId,
      message: result.message ?? result.submit?.message ?? "Connection failed."
    });
  }
  await clearAppStateCache();
  return setFlow({ phase: "done", flowId, profile: null });
}
async function maybeAutoConnect(forceAppState = false) {
  if (flow.phase !== "idle") return;
  const stored = await chrome.storage.session.get("autoConnect");
  const lastAttemptAt = stored.autoConnect?.lastAttemptAt ?? 0;
  if (Date.now() - lastAttemptAt < AUTO_CONNECT_COOLDOWN_MS) return;
  await chrome.storage.session.set({ autoConnect: { lastAttemptAt: Date.now() } });
  const state = await requestAppState(forceAppState);
  if (!state.ok || !state.appState) return;
  if (state.appState.connection) return;
  if (!await hasSubstackSession()) return;
  await runConnectFlow({ focusSubstack: false, askPublication: false });
}
async function handlePopupRequest(request) {
  switch (request.type) {
    case "GET_STATUS": {
      void maybeAutoConnect();
      const [substackLoggedIn, app] = await Promise.all([
        hasSubstackSession(),
        requestAppState(true)
      ]);
      const appHandles = handlesFromAppState(app);
      const currentFlow = recoveredFlow(flow, Boolean(app.ok && app.appState?.connection), connectRequest !== null);
      if (currentFlow !== flow) await setFlow(currentFlow);
      if (appHandles) crmHandles = appHandles;
      let appState = "unreachable";
      let appProfile = null;
      let appUserEmail = null;
      if (app.ok && app.appState) {
        appState = app.appState.connection ? "connected" : "none";
        appProfile = app.appState.connection?.profile.name ?? app.appState.connection?.profile.handle ?? null;
        appUserEmail = app.appState.user?.email ?? null;
      } else if (app.needsAuth) {
        appState = "needsAuth";
      }
      return {
        ok: true,
        flow,
        substackLoggedIn,
        appState,
        appProfile,
        appUserEmail,
        appPublicationUrl: app.ok && app.appState ? app.appState.connection?.publicationUrl ?? null : null
      };
    }
    case "START_CONNECT_FLOW":
      return { ok: true, flow: await runConnectFlow() };
    case "connect-from-app":
      return { ok: true, flow: await runConnectFlow() };
    case "APP_PAGE_LOADED":
      await clearAppStateCache();
      void drainActivity(requestViaBridge).catch((error) => console.warn("[Circles Activity] Queue retry failed.", error));
      void maybeAutoConnect(true);
      return { ok: true };
    case "SUBMIT_PUBLICATION_URL": {
      if (flow.phase !== "asking-publication" || flow.flowId !== request.flowId) {
        return { ok: false, message: "No connection is waiting for a publication URL." };
      }
      pendingPublicationUrl = {
        flowId: request.flowId,
        url: request.publicationUrl
      };
      return { ok: true };
    }
    case "ADD_FEED_PERSON": {
      const handle = request.handle.trim().toLocaleLowerCase("en");
      const name = request.name.trim().replace(/\s+/g, " ").slice(0, 80);
      if (!/^[a-z0-9](?:[a-z0-9_-]{0,62}[a-z0-9])?$/.test(handle)) {
        return { ok: false, message: "Invalid Substack handle." };
      }
      if (!name) {
        return { ok: false, message: "Could not read the author's name." };
      }
      const result = await requestConnectBridge({
        type: "POST_CREATE_PERSON",
        name,
        handle,
        lists: request.lists.slice(0, 20),
        tags: []
      });
      const ok = result.ok && result.submit?.ok !== false;
      const message = result.submit?.message ?? result.message ?? (ok ? "Added." : "Failed.");
      if (ok) {
        await rememberCrmHandle(handle, name, request.lists);
      }
      return {
        ok,
        message,
        alreadyInCrm: !ok && /already/i.test(message),
        memberLists: crmMembers?.get(handle)?.lists ?? []
      };
    }
    case "GET_CRM_STATUS": {
      const normalized = request.handle.trim().toLocaleLowerCase("en");
      if (!crmHandles || !crmMembers) {
        const app = await requestAppState();
        const appHandles = handlesFromAppState(app);
        if (appHandles) crmHandles = appHandles;
      }
      const inCrm = crmHandles?.has(normalized) ?? false;
      const memberLists = crmMembers?.get(normalized)?.lists ?? [];
      if (inCrm) {
        console.log(`[Circles Background] @${normalized} is in CRM with lists:`, memberLists);
      }
      return { ok: true, inCrm, memberLists };
    }
    case "GET_CURRENT_PROFILE": {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      return { ok: true, profile: tab ? detectProfileFromTab(tab) : null };
    }
    case "FETCH_LISTS": {
      const state = await requestAppState();
      return {
        ok: state.ok,
        message: state.message,
        needsAuth: state.needsAuth,
        lists: state.appState?.lists ?? []
      };
    }
    case "CAPTURE_ACTIVITY_BATCH": {
      await requestAppState();
      const queued = await enqueueActivity(request.payload);
      if (queued.ok) void drainActivity(requestViaBridge).catch((error) => console.warn("[Circles Activity] Delivery interrupted; pending data retained.", error));
      return queued;
    }
    case "ADD_TO_LISTS": {
      const handle = request.handle.trim().toLocaleLowerCase("en");
      const result = await requestViaBridge({
        type: "POST_CREATE_PERSON",
        name: request.name,
        handle,
        lists: request.lists,
        tags: request.tags
      });
      const ok = result.ok && result.submit?.ok !== false;
      if (ok) await rememberCrmHandle(handle, request.name, request.lists);
      return {
        ok,
        message: result.message ?? result.submit?.message,
        submit: result.submit,
        memberLists: crmMembers?.get(handle)?.lists ?? []
      };
    }
  }
}
chrome.runtime.onMessage.addListener(
  (request, sender, sendResponse) => {
    if (request.type === "CAPTURE_ACTIVITY_BATCH" && !isSubstackPageUrl(sender.url)) {
      sendResponse({ ok: false, message: "Activity capture source was rejected." });
      return;
    }
    if (["APP_PAGE_LOADED", "connect-from-app", "SUBMIT_PUBLICATION_URL"].includes(request.type) && !isAppOriginUrl(sender.url)) {
      if (sender.url !== chrome.runtime.getURL("popup/popup.html")) {
        sendResponse({ ok: false, message: "App message source was rejected." });
        return;
      }
    }
    void initialized.then(() => handlePopupRequest(request)).then(sendResponse).catch(() => sendResponse({ ok: false, message: "Request failed; capture was not confirmed." }));
    return true;
  }
);
chrome.runtime.onMessageExternal.addListener(
  (request, _sender, sendResponse) => {
    if (request?.type === "ping") {
      sendResponse({ ok: true, installed: true });
      return;
    }
    if (request?.type === "connect-from-app") {
      void initialized.then(() => runConnectFlow()).then(sendResponse).catch(() => sendResponse({ ok: false, message: "Connection failed." }));
      return true;
    }
    sendResponse({ ok: false, message: "Unknown request." });
  }
);
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ACTIVITY_RETRY_ALARM) {
    void drainActivity(requestViaBridge).catch((error) => console.warn("[Circles Activity] Queue retry interrupted.", error));
  }
});
void chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" }).catch((error) => console.warn("[Circles Activity] Could not restrict capture storage access.", error));
void chrome.alarms.get(ACTIVITY_RETRY_ALARM).then((alarm) => {
  if (!alarm) return chrome.alarms.create(ACTIVITY_RETRY_ALARM, { periodInMinutes: 1 });
}).catch((error) => console.warn("[Circles Activity] Could not schedule retries.", error));
async function waitForTabLoad(tabId, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === "complete") return;
    } catch {
      return;
    }
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
}
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason !== "install") return;
  void chrome.tabs.create({ url: `${APP_ORIGINS[0]}` }).then(async (tab) => {
    if (!tab.id) return;
    await waitForTabLoad(tab.id, 2e4);
    await requestViaBridge({ type: "POST_INSTALL" });
    const state = await requestAppState();
    if (state.ok && state.appState && !state.appState.connection) {
      await runConnectFlow();
    }
  }).catch(() => void 0);
});
var initialized = readStoredFlow();
