"use strict";
(() => {
  // src/activity-bridge.ts
  var MESSAGE_SOURCE = "circles-page-observer";
  var observedActivityBatches = /* @__PURE__ */ new Set();
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const message = event.data;
    if (message?.source !== MESSAGE_SOURCE || !["ACTIVITY_RESPONSE", "CONVERSATION_RESPONSE", "OUTBOUND_ACTION"].includes(message.type ?? "") || !(Array.isArray(message.payload?.activityItems) || message.payload?.kind === "conversation" && Array.isArray(message.payload.comments) || message.payload?.kind === "outbound-action")) return;
    const items = message.payload.kind === "outbound-action" ? [message.payload] : message.payload.activityItems ?? message.payload.comments;
    const batchKey = JSON.stringify(message.payload);
    if (observedActivityBatches.has(batchKey)) {
      console.log(`[Circles Activity] Skipped duplicate batch (${items.length} items).`);
      return;
    }
    console.log(`[Circles Activity] Forwarding ${items.length} captured items to Circles.`);
    void chrome.runtime.sendMessage({
      type: "CAPTURE_ACTIVITY_BATCH",
      payload: message.payload
    }).then((result) => {
      if (result?.ok) {
        observedActivityBatches.add(batchKey);
        if (observedActivityBatches.size > 20) {
          const oldest = observedActivityBatches.values().next().value;
          if (oldest !== void 0) observedActivityBatches.delete(oldest);
        }
        console.log(
          result.queued ? `[Circles Activity] Safely queued ${items.length} items locally; ${result.pendingBatches ?? 0} batches awaiting delivery.` : `[Circles Activity] Batch already delivered (${items.length} items).`
        );
      } else {
        console.warn(
          `[Circles Activity] Capture was not queued; reload Activity to retry. ${result?.message ?? ""}`.trim()
        );
      }
    }).catch((error) => {
      console.warn("[Circles Activity] Could not reach the extension background worker; scheduled sync remains the fallback.", error);
    });
  });
})();
//# sourceMappingURL=activity-bridge.js.map
