"use strict";
(() => {
  // src/lib/conversation-capture.ts
  var record = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
  var text = (value, max) => typeof value === "string" && value.length <= max ? value : null;
  var id = (value) => typeof value === "string" && /^[0-9]+$/.test(value) && value.length <= 512 || typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? String(value) : null;
  function safeUrl(value) {
    try {
      const url = new URL(String(value));
      return url.protocol === "https:" && !url.username && !url.password ? url.href : null;
    } catch {
      return null;
    }
  }
  function conversationTarget(url) {
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "https:" || parsed.username || parsed.password || !(parsed.hostname === "substack.com" || parsed.hostname.endsWith(".substack.com"))) return null;
      const note = /^\/api\/v1\/reader\/comment\/(\d+)\/replies$/.exec(parsed.pathname);
      const post = /^\/api\/v1\/post\/(\d+)\/comments$/.exec(parsed.pathname);
      if (!note && !post) return null;
      return { targetType: note ? "note" : "post", targetId: (note ?? post)[1], sourceUrl: parsed.origin + parsed.pathname };
    } catch {
      return null;
    }
  }
  function normalizeConversationResponse(url, payload) {
    const target = conversationTarget(url);
    const data = record(payload);
    if (!target || !data) return null;
    const branches = target.targetType === "note" ? data.commentBranches ?? data.comments : data.comments;
    if (!Array.isArray(branches)) return null;
    let count = 0;
    function reply(value, depth) {
      const branch = record(value);
      const comment = record(branch?.comment) ?? branch;
      if (!comment || !id(comment.id) || typeof comment.body !== "string") throw new Error("Unsupported conversation comment shape.");
      if (++count > 1e3 || depth > 20 || comment.body.length > 1e5) throw new Error("Conversation exceeds capture safety limits; no partial tree was queued.");
      const user = record(comment.user) ?? record(comment.author) ?? record(branch?.user);
      const children = branch?.children ?? branch?.descendantComments ?? branch?.replies ?? [];
      if (!Array.isArray(children)) throw new Error("Invalid conversation children.");
      return {
        id: id(comment.id),
        body: comment.body,
        createdAt: text(comment.createdAt ?? comment.date ?? comment.created_at, 128),
        authorName: text(comment.authorName ?? comment.name ?? user?.name, 256),
        authorHandle: text(comment.authorHandle ?? comment.handle ?? user?.handle, 256),
        authorPhotoUrl: safeUrl(comment.authorPhotoUrl ?? comment.photo_url ?? comment.photoUrl ?? user?.photo_url ?? user?.photoUrl),
        authorId: id(comment.authorId ?? user?.id ?? comment.user_id),
        children: children.map((child) => reply(child, depth + 1))
      };
    }
    const comments = branches.map((branch) => reply(branch, 0));
    let rootAuthor = null;
    const root = record(data.rootComment ?? data.rootAuthor);
    if (root && typeof root.body === "string") rootAuthor = reply({ ...root, children: [] }, 0);
    const more = data.moreBranches ?? data.moreComments ?? 0;
    if (typeof more !== "number" || !Number.isSafeInteger(more) || more < 0) throw new Error("Invalid conversation pagination.");
    return { kind: "conversation", ...target, comments, rootAuthor, moreComments: more, nextCursor: text(data.nextCursor, 2048) };
  }

  // src/lib/activity-pagination.ts
  function activityPageEvidence(url, payload) {
    let request;
    try {
      request = new URL(url);
    } catch {
      return null;
    }
    if (request.origin !== "https://substack.com" || request.pathname !== "/api/v1/activity-feed-web") return null;
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) return null;
    const page = payload;
    if (!Array.isArray(page.activityItems)) return null;
    const date = (value) => typeof value === "string" && /^\d{4}-\d{2}-\d{2}T/.test(value) && Number.isFinite(Date.parse(value)) ? new Date(value).toISOString() : null;
    const last = page.activityItems.at(-1);
    const item = last && typeof last === "object" && !Array.isArray(last) ? last : {};
    return {
      after: date(request.searchParams.get("after")),
      more: typeof page.more === "boolean" ? page.more : null,
      count: page.activityItems.length,
      lastCreatedAt: date(item.created_at),
      lastUpdatedAt: date(item.updated_at)
    };
  }

  // src/page-observer.ts
  var ACTIVITY_PATH = "/api/v1/activity-feed-web";
  var MESSAGE_SOURCE = "circles-page-observer";
  var MAX_CAPTURE_BYTES = 2e6;
  function isActivityResponse(url) {
    try {
      const parsed = new URL(url, window.location.href);
      return parsed.protocol === "https:" && (parsed.hostname === "substack.com" || parsed.hostname.endsWith(".substack.com")) && parsed.pathname === ACTIVITY_PATH;
    } catch {
      return false;
    }
  }
  function publishPayload(payload, transport, url) {
    try {
      const conversation = normalizeConversationResponse(new URL(url, window.location.href).href, payload);
      if (conversation) {
        if (new TextEncoder().encode(JSON.stringify(conversation)).length > MAX_CAPTURE_BYTES) throw new Error("Conversation exceeds upload size limit.");
        console.log(`[Circles Activity] Captured ${conversation.targetType} conversation from an existing ${transport} response; ${conversation.moreComments} more comments reported.`);
        window.postMessage({ source: MESSAGE_SOURCE, type: "CONVERSATION_RESPONSE", payload: conversation }, window.location.origin);
        return;
      }
      if (conversationTarget(new URL(url, window.location.href).href)) {
        console.warn("[Circles Activity] Unsupported response shape; conversation was not queued.");
        return;
      }
      const serialized = JSON.stringify(payload);
      if (serialized.length === 0 || serialized.length > MAX_CAPTURE_BYTES) {
        console.warn("[Circles Activity] Ignored an empty or oversized activity response.");
        return;
      }
      const record2 = payload;
      if (!record2 || !Array.isArray(record2.activityItems)) return;
      console.log(
        `[Circles Activity] Detected ${record2.activityItems.length} activity items from an existing Substack ${transport} response.`
      );
      const evidence = activityPageEvidence(new URL(url, window.location.href).href, payload);
      if (evidence) console.log("[Circles Activity] Pagination evidence (no extra requests):", evidence);
      window.postMessage(
        { source: MESSAGE_SOURCE, type: "ACTIVITY_RESPONSE", payload },
        window.location.origin
      );
    } catch (error) {
      console.warn("[Circles Activity] Response could not be captured completely.", error);
    }
  }
  function observeResponse(response) {
    if (!response.ok || !(isActivityResponse(response.url) || conversationTarget(response.url))) return;
    void response.clone().json().then((payload) => publishPayload(payload, "fetch", response.url)).catch(() => {
      console.warn("[Circles Activity] Could not read the observed Substack activity response.");
    });
  }
  var originalFetch = window.fetch;
  window.fetch = async function circlesObservedFetch(...args) {
    const response = await originalFetch.apply(this, args);
    observeResponse(response);
    return response;
  };
  var originalOpen = XMLHttpRequest.prototype.open;
  var originalSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function circlesObservedOpen(method, url, asyncFlag = true, username, password) {
    Object.defineProperty(this, "__circlesActivityUrl", {
      configurable: true,
      value: String(url)
    });
    return originalOpen.call(this, method, url, asyncFlag, username, password);
  };
  XMLHttpRequest.prototype.send = function circlesObservedSend(body) {
    this.addEventListener("load", () => {
      const url = this.__circlesActivityUrl;
      if (!url || this.status < 200 || this.status >= 300 || !(isActivityResponse(url) || conversationTarget(new URL(url, window.location.href).href))) return;
      try {
        publishPayload(this.responseType === "json" ? this.response : JSON.parse(this.responseText), "xhr", url);
      } catch {
      }
    }, { once: true });
    return originalSend.call(this, body);
  };
  console.log("[Circles Activity] Passive observer installed; no extra Substack requests will be made.");
})();
//# sourceMappingURL=page-observer.js.map
