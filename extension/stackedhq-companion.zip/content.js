"use strict";
(() => {
  // src/lib/constants.ts
  var APP_ORIGINS = [
    "https://stackedhq.chillital.com",
    "http://localhost:5173"
  ];
  var APP_ORIGIN = APP_ORIGINS[0];
  var EXTENSION_HEADER = "X-StackedHQ-Extension";
  var EXTENSION_HEADER_VALUE = "v1";
  var CONNECT_FLOW_TIMEOUT_MS = 5 * 6e4;
  var AUTO_CONNECT_COOLDOWN_MS = 30 * 6e4;

  // src/content.ts
  var ORIGIN = window.location.origin;
  function extensionHeaders() {
    return { [EXTENSION_HEADER]: EXTENSION_HEADER_VALUE };
  }
  function formValue(form, name, value) {
    if (value) form.set(name, value);
    return form;
  }
  function submitResult(data) {
    const record = data;
    const ok = record?.ok !== false;
    return {
      ok,
      message: record?.message ?? (ok ? "Saved." : "Failed.")
    };
  }
  async function getAppState() {
    console.log("[StackedHQ Companion Bridge] Fetching app state from StackedHQ app...");
    try {
      const response = await fetch(`${ORIGIN}/api/ext/companion`, {
        headers: extensionHeaders(),
        credentials: "same-origin"
      });
      if (response.redirected && response.url.includes("/sign-in")) {
        console.warn("[StackedHQ Companion Bridge] App session is unauthenticated (redirected to /sign-in).");
        return { ok: false, needsAuth: true, message: "Log in to StackedHQ first." };
      }
      if (!response.ok) {
        console.error(`[StackedHQ Companion Bridge] App returned status ${response.status}.`);
        return { ok: false, message: `StackedHQ app bridge is not ready yet (${response.status}).` };
      }
      const appState = await response.json();
      console.log(
        "%c[StackedHQ Companion Bridge] App state loaded:",
        "color: #10b981; font-weight: bold;",
        {
          connected: Boolean(appState?.connection),
          handlesCount: appState?.handles?.length ?? 0,
          listsCount: appState?.lists?.length ?? 0
        }
      );
      return { ok: true, appState };
    } catch (error) {
      console.error("[StackedHQ Companion Bridge] Error connecting to StackedHQ:", error);
      return { ok: false, message: "Could not reach StackedHQ." };
    }
  }
  async function postForm(path, form) {
    try {
      const response = await fetch(`${ORIGIN}${path}`, {
        method: "POST",
        headers: extensionHeaders(),
        body: form,
        credentials: "same-origin"
      });
      if (response.redirected && response.url.includes("/sign-in")) {
        return { ok: false, needsAuth: true, message: "Log in to StackedHQ first." };
      }
      if (!response.ok) {
        return { ok: false, message: `StackedHQ returned ${response.status}.` };
      }
      const data = await response.json().catch(() => null);
      return { ok: submitResult(data).ok, submit: submitResult(data) };
    } catch {
      return { ok: false, message: "Could not reach StackedHQ." };
    }
  }
  async function postJson(path, value) {
    try {
      const response = await fetch(`${ORIGIN}${path}`, {
        method: "POST",
        headers: {
          ...extensionHeaders(),
          "Content-Type": "application/json"
        },
        body: JSON.stringify(value),
        credentials: "same-origin"
      });
      if (response.redirected && response.url.includes("/sign-in")) {
        return { ok: false, needsAuth: true, message: "Log in to StackedHQ first." };
      }
      if (!response.ok) {
        return { ok: false, message: `StackedHQ returned ${response.status}.` };
      }
      const data = await response.json().catch(() => null);
      return {
        ok: data?.ok !== false,
        message: data?.message,
        captured: data?.captured,
        processedItems: data?.processedItems,
        newInteractions: data?.newInteractions,
        newPeople: data?.newPeople,
        updatedPeople: data?.updatedPeople
      };
    } catch {
      return { ok: false, message: "Could not reach StackedHQ." };
    }
  }
  async function handle(request) {
    switch (request.type) {
      case "GET_APP_STATE":
        return getAppState();
      case "POST_CONNECT": {
        const form = new FormData();
        form.set("intent", "connect");
        form.set("envelope", JSON.stringify(request.envelope));
        formValue(form, "publicationUrl", request.publicationUrl);
        return postForm("/app/settings", form);
      }
      case "POST_INSTALL": {
        const form = new FormData();
        form.set("intent", "install");
        return postForm("/app/companion", form);
      }
      case "POST_ACTIVITY_BATCH": {
        const count = Array.isArray(
          request.payload?.activityItems
        ) ? request.payload.activityItems.length : 0;
        console.log(`[StackedHQ Companion Bridge] Sending ${count} captured activity items to StackedHQ.`);
        const result = await postJson("/api/ext/activity", request.payload);
        if (result.ok) {
          console.log(
            `[StackedHQ Companion Bridge] Activity stored: ${result.newInteractions ?? 0} new interactions, ${result.newPeople ?? 0} new people.`
          );
          window.dispatchEvent(new CustomEvent("stackedhq:activity-captured"));
        } else {
          console.warn(
            `[StackedHQ Companion Bridge] Activity capture failed. ${result.message ?? "Scheduled sync will retry."}`
          );
        }
        return result;
      }
      case "POST_CREATE_PERSON": {
        const form = new FormData();
        form.set("intent", "createPerson");
        form.set("name", request.name);
        form.set("handle", request.handle);
        for (const listId of request.lists) form.append("lists", listId);
        for (const tag of request.tags) form.append("tags", tag);
        return postForm("/app/community", form);
      }
    }
  }
  chrome.runtime.onMessage.addListener(
    (request, _sender, sendResponse) => {
      void handle(request).then(sendResponse);
      return true;
    }
  );
  document.documentElement.dataset.stackedhqExtension = "v1";
  window.dispatchEvent(new CustomEvent("stackedhq:extension-detected"));
  chrome.runtime.sendMessage({ type: "APP_PAGE_LOADED" }).catch(() => void 0);
  window.addEventListener("stackedhq:connect-request", () => {
    void chrome.runtime.sendMessage({ type: "connect-from-app" }).catch(() => void 0);
  });
  window.addEventListener("stackedhq:submit-publication", (event) => {
    const detail = event.detail;
    if (!detail?.flowId) return;
    void chrome.runtime.sendMessage({
      type: "SUBMIT_PUBLICATION_URL",
      flowId: detail.flowId,
      publicationUrl: detail.publicationUrl ?? null
    }).catch(() => void 0);
  });
  chrome.runtime.onMessage.addListener((message) => {
    const record = message;
    if (record.type === "FLOW_CHANGED") {
      window.dispatchEvent(
        new CustomEvent("stackedhq:flow-changed", { detail: record.flow })
      );
    }
  });
})();
//# sourceMappingURL=content.js.map
