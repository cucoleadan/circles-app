"use strict";
(() => {
  // src/page-observer.ts
  var ACTIVITY_PATH = "/api/v1/activity-feed-web";
  var MESSAGE_SOURCE = "stackedhq-page-observer";
  var MAX_CAPTURE_BYTES = 2e6;
  function isActivityResponse(url) {
    try {
      const parsed = new URL(url, window.location.href);
      return parsed.protocol === "https:" && (parsed.hostname === "substack.com" || parsed.hostname.endsWith(".substack.com")) && parsed.pathname === ACTIVITY_PATH;
    } catch {
      return false;
    }
  }
  function publishPayload(payload, transport) {
    try {
      const serialized = JSON.stringify(payload);
      if (serialized.length === 0 || serialized.length > MAX_CAPTURE_BYTES) {
        console.warn("[StackedHQ Activity] Ignored an empty or oversized activity response.");
        return;
      }
      const record = payload;
      if (!record || !Array.isArray(record.activityItems)) return;
      console.log(
        `[StackedHQ Activity] Detected ${record.activityItems.length} activity items from an existing Substack ${transport} response.`
      );
      window.postMessage(
        { source: MESSAGE_SOURCE, type: "ACTIVITY_RESPONSE", payload },
        window.location.origin
      );
    } catch {
    }
  }
  function observeResponse(response) {
    if (!response.ok || !isActivityResponse(response.url)) return;
    void response.clone().json().then((payload) => publishPayload(payload, "fetch")).catch(() => {
      console.warn("[StackedHQ Activity] Could not read the observed Substack activity response.");
    });
  }
  var originalFetch = window.fetch;
  window.fetch = async function stackedHqObservedFetch(...args) {
    const response = await originalFetch.apply(this, args);
    observeResponse(response);
    return response;
  };
  var originalOpen = XMLHttpRequest.prototype.open;
  var originalSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function stackedHqObservedOpen(method, url, asyncFlag = true, username, password) {
    Object.defineProperty(this, "__stackedHqActivityUrl", {
      configurable: true,
      value: String(url)
    });
    return originalOpen.call(this, method, url, asyncFlag, username, password);
  };
  XMLHttpRequest.prototype.send = function stackedHqObservedSend(body) {
    this.addEventListener("load", () => {
      const url = this.__stackedHqActivityUrl;
      if (!url || this.status < 200 || this.status >= 300 || !isActivityResponse(url)) return;
      try {
        publishPayload(JSON.parse(this.responseText), "xhr");
      } catch {
      }
    }, { once: true });
    return originalSend.call(this, body);
  };
  console.log("[StackedHQ Activity] Passive observer installed; no extra Substack requests will be made.");
})();
//# sourceMappingURL=page-observer.js.map
