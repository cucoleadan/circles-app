// src/lib/constants.ts
var APP_ORIGINS = [
  "https://stackedhq.chillital.com",
  "http://localhost:5173"
];
var APP_ORIGIN = APP_ORIGINS[0];
var CONNECT_FLOW_TIMEOUT_MS = 5 * 6e4;
var CONNECT_POLL_INTERVAL_MS = 1e3;
var AUTO_CONNECT_COOLDOWN_MS = 30 * 6e4;
var SUBSTACK_SESSION_COOKIE = "substack.sid";

// src/lib/crypto.ts
function toArrayBuffer(bytes) {
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  return copy.buffer;
}
function base64ToBytes(value) {
  const binary = atob(value.replace(/\s/g, ""));
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}
function base64UrlEncode(value) {
  const bytes = new Uint8Array(value);
  let binary = "";
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function publicKeyDer(publicKeyPem) {
  const base64 = publicKeyPem.replace("-----BEGIN PUBLIC KEY-----", "").replace("-----END PUBLIC KEY-----", "");
  return toArrayBuffer(base64ToBytes(base64));
}
async function encryptConnectionCredential({
  publicKeyPem,
  keyId,
  credential
}) {
  if (!credential.trim()) {
    throw new Error("A Substack session credential is required.");
  }
  const publicKey = await crypto.subtle.importKey(
    "spki",
    publicKeyDer(publicKeyPem),
    { name: "RSA-OAEP", hash: "SHA-256" },
    false,
    ["encrypt"]
  );
  const aesKey = await crypto.subtle.generateKey(
    { name: "AES-GCM", length: 256 },
    true,
    ["encrypt"]
  );
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: toArrayBuffer(iv) },
    aesKey,
    new TextEncoder().encode(credential)
  );
  const wrappedKey = await crypto.subtle.encrypt(
    { name: "RSA-OAEP" },
    publicKey,
    await crypto.subtle.exportKey("raw", aesKey)
  );
  return {
    version: 1,
    keyId,
    wrappedKey: base64UrlEncode(wrappedKey),
    iv: base64UrlEncode(toArrayBuffer(iv)),
    ciphertext: base64UrlEncode(ciphertext)
  };
}

// src/lib/cookies.ts
function isSubstackCookie(cookie) {
  const host = cookie.domain.startsWith(".") ? cookie.domain.slice(1) : cookie.domain;
  return host === "substack.com" || host.endsWith(".substack.com");
}
function substackCookies() {
  return chrome.cookies.getAll({}).then((all) => all.filter(isSubstackCookie));
}
async function getSubstackSessionValue() {
  const cookies = await substackCookies();
  const sid = cookies.find((cookie) => cookie.name === SUBSTACK_SESSION_COOKIE);
  return sid && sid.value.length > 0 ? sid.value : null;
}
async function hasSubstackSession() {
  return await getSubstackSessionValue() !== null;
}

// src/lib/detect.ts
function detectProfileFromTab(tab) {
  const url = tab.url ?? "";
  const pathname = (() => {
    try {
      return new URL(url).pathname;
    } catch {
      return "";
    }
  })();
  const handleMatch = pathname.match(
    /^\/(?:@([^/?#]+)|profile\/\d+-([^/?#]+))(?:\/.*)?$/
  );
  const handle = handleMatch?.[1] ?? handleMatch?.[2];
  if (!handle) return null;
  let name = null;
  const title = (tab.title ?? "").replace(/\s*-\s*Substack\s*$/i, "").trim();
  if (title && !title.includes("@") && title.length <= 80) {
    name = title;
  }
  return { handle: handle.toLocaleLowerCase("en"), name, pageUrl: url };
}

// src/background.ts
var flow = { phase: "idle" };
var encryptionConfig = null;
var pendingPublicationUrl = null;
var crmHandles = null;
var crmMembers = null;
var appStateRequest = null;
var PUBLICATION_ASK_TIMEOUT_MS = 12e4;
var APP_STATE_CACHE_KEY = "appStateCache";
var APP_STATE_SUCCESS_TTL_MS = 5 * 6e4;
var APP_STATE_ERROR_TTL_MS = 6e4;
function populateMemberCache(state) {
  if (!state.ok || !state.appState) return;
  const handles = /* @__PURE__ */ new Set();
  const members = /* @__PURE__ */ new Map();
  for (const handle of state.appState.handles ?? []) {
    handles.add(handle.toLocaleLowerCase("en"));
  }
  for (const member of state.appState.members ?? []) {
    const key = member.handle.toLocaleLowerCase("en");
    handles.add(key);
    members.set(key, { name: member.name, lists: member.lists ?? [] });
  }
  crmHandles = handles;
  crmMembers = members;
}
function handlesFromAppState(state) {
  if (!state.ok || !state.appState) return null;
  populateMemberCache(state);
  return crmHandles;
}
async function waitForPublicationUrl(flowId) {
  const deadline = Date.now() + PUBLICATION_ASK_TIMEOUT_MS;
  while (Date.now() < deadline) {
    if (pendingPublicationUrl && pendingPublicationUrl.flowId === flowId) {
      const { url } = pendingPublicationUrl;
      pendingPublicationUrl = null;
      return url;
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  pendingPublicationUrl = null;
  return null;
}
async function readStoredFlow() {
  const stored = await chrome.storage.session.get("flow");
  if (stored.flow && typeof stored.flow === "object") {
    flow = stored.flow;
  }
}
async function setFlow(next) {
  flow = next;
  await chrome.storage.session.set({ flow: next });
  void chrome.runtime.sendMessage({ type: "FLOW_CHANGED", flow: next }).catch(() => void 0);
  return next;
}
function isAppOriginUrl(url) {
  if (!url) return false;
  return APP_ORIGINS.some((origin) => url.startsWith(origin));
}
function isSubstackPageUrl(url) {
  if (!url) return false;
  try {
    const parsed = new URL(url);
    return parsed.protocol === "https:" && (parsed.hostname === "substack.com" || parsed.hostname.endsWith(".substack.com"));
  } catch {
    return false;
  }
}
async function findBridgeTab() {
  const tabs = await chrome.tabs.query({
    url: APP_ORIGINS.map((origin) => `${origin}/*`)
  });
  const appTabs = tabs.filter((tab) => isAppOriginUrl(tab.url));
  return appTabs.find((tab) => tab.url?.includes("/app/")) ?? appTabs[0] ?? null;
}
async function requestViaBridge(request) {
  const tab = await findBridgeTab();
  if (!tab?.id) {
    return { ok: false, message: "Open the StackedHQ app in a tab first." };
  }
  try {
    return await chrome.tabs.sendMessage(tab.id, request);
  } catch {
    return {
      ok: false,
      message: "The StackedHQ page is not ready yet. Reload it and try again."
    };
  }
}
async function requestAppState(force = false) {
  if (appStateRequest) return appStateRequest;
  appStateRequest = (async () => {
    if (!force) {
      const stored = await chrome.storage.session.get(APP_STATE_CACHE_KEY);
      const cached = stored[APP_STATE_CACHE_KEY];
      if (cached?.expiresAt && cached.expiresAt > Date.now()) {
        return cached.response;
      }
    }
    const response = await requestViaBridge({ type: "GET_APP_STATE" });
    const ttl = response.ok && response.appState ? APP_STATE_SUCCESS_TTL_MS : APP_STATE_ERROR_TTL_MS;
    await chrome.storage.session.set({
      [APP_STATE_CACHE_KEY]: { response, expiresAt: Date.now() + ttl }
    });
    return response;
  })();
  try {
    return await appStateRequest;
  } finally {
    appStateRequest = null;
  }
}
async function clearAppStateCache() {
  await chrome.storage.session.remove(APP_STATE_CACHE_KEY);
}
async function rememberCrmHandle(handle, name, listIds) {
  const normalized = handle.toLocaleLowerCase("en");
  crmHandles?.add(normalized);
  const stored = await chrome.storage.session.get(APP_STATE_CACHE_KEY);
  const cached = stored[APP_STATE_CACHE_KEY];
  const appState = cached?.response.appState;
  const allLists = appState?.lists ?? [];
  const assignedLists = listIds ? allLists.filter((list) => listIds.includes(list.id)) : [];
  const existingMember = crmMembers?.get(normalized);
  const updatedLists = [
    ...existingMember?.lists ?? [],
    ...assignedLists.filter(
      (assigned) => !(existingMember?.lists ?? []).some((item) => item.id === assigned.id)
    )
  ];
  if (!crmMembers) crmMembers = /* @__PURE__ */ new Map();
  crmMembers.set(normalized, {
    name: name ?? existingMember?.name ?? normalized,
    lists: updatedLists
  });
  if (!appState) return;
  const handles = new Set(appState.handles ?? []);
  handles.add(normalized);
  const members = [...(appState.members ?? []).filter((m) => m.handle.toLocaleLowerCase("en") !== normalized)];
  members.push({
    handle: normalized,
    name: name ?? existingMember?.name ?? normalized,
    lists: updatedLists
  });
  await chrome.storage.session.set({
    [APP_STATE_CACHE_KEY]: {
      ...cached,
      response: {
        ...cached.response,
        appState: { ...appState, handles: [...handles], members }
      }
    }
  });
}
async function sendToTab(tabId, request) {
  try {
    return await chrome.tabs.sendMessage(tabId, request);
  } catch {
    return null;
  }
}
async function openBridgeTab() {
  const tab = await chrome.tabs.create({
    url: `${APP_ORIGIN}/app/companion`,
    active: true
  });
  if (tab.id) {
    await waitForTabLoad(tab.id, 3e4);
  }
  return tab;
}
async function requestConnectBridge(request) {
  const existing = await findBridgeTab();
  const tab = existing?.id ? existing : await openBridgeTab();
  if (!tab?.id) {
    return { ok: false, message: "Open the StackedHQ app in a tab first." };
  }
  let response = await sendToTab(tab.id, request);
  if (!response) {
    try {
      await chrome.tabs.reload(tab.id);
      await waitForTabLoad(tab.id, 3e4);
    } catch {
      return {
        ok: false,
        message: "The StackedHQ page is not ready yet. Reload it and try again."
      };
    }
    response = await sendToTab(tab.id, request);
  }
  return response ?? {
    ok: false,
    message: "The StackedHQ page is not ready yet. Reload it and try again."
  };
}
async function openOrFocusSubstackTab(focus) {
  const existing = await chrome.tabs.query({ url: "https://*.substack.com/*" });
  const candidate = existing[0];
  if (candidate?.id) {
    if (focus) {
      await chrome.tabs.update(candidate.id, { active: true });
    }
    return candidate;
  }
  return chrome.tabs.create({
    url: "https://substack.com/signin",
    ...focus ? {} : { active: false }
  });
}
async function waitForSubstackSession() {
  const deadline = Date.now() + CONNECT_FLOW_TIMEOUT_MS;
  while (Date.now() < deadline) {
    if (await hasSubstackSession()) return true;
    await new Promise((resolve) => setTimeout(resolve, CONNECT_POLL_INTERVAL_MS));
  }
  return false;
}
async function runConnectFlow(options) {
  if (flow.phase === "waiting-substack-login" || flow.phase === "asking-publication" || flow.phase === "sending") {
    return flow;
  }
  const flowId = crypto.randomUUID();
  const startedAt = Date.now();
  let publicationUrl = null;
  if (options?.askPublication !== false) {
    await setFlow({ phase: "asking-publication", flowId, startedAt });
    publicationUrl = await waitForPublicationUrl(flowId);
  }
  await setFlow({ phase: "waiting-substack-login", flowId, startedAt });
  await openOrFocusSubstackTab(options?.focusSubstack ?? true);
  if (!await waitForSubstackSession()) {
    return setFlow({
      phase: "failed",
      flowId,
      message: "Timed out waiting for a Substack login. Log in and try again."
    });
  }
  let config = encryptionConfig;
  if (!config) {
    const state = await requestAppState();
    if (!state.ok) {
      return setFlow({
        phase: "failed",
        flowId,
        message: state.needsAuth ? "Log in to StackedHQ first." : state.message ?? "Could not reach the StackedHQ app."
      });
    }
    if (!state.appState?.encryption) {
      return setFlow({
        phase: "failed",
        flowId,
        message: "StackedHQ connection encryption is not configured yet."
      });
    }
    config = state.appState.encryption;
    encryptionConfig = config;
  }
  const credential = await getSubstackSessionValue();
  if (!credential) {
    return setFlow({
      phase: "failed",
      flowId,
      message: "Could not read the Substack session cookie. Log in again and retry."
    });
  }
  await setFlow({ phase: "sending", flowId });
  let envelope;
  try {
    envelope = await encryptConnectionCredential({
      publicKeyPem: config.publicKeyPem,
      keyId: config.keyId,
      credential
    });
  } catch {
    return setFlow({
      phase: "failed",
      flowId,
      message: "Could not encrypt the Substack credential."
    });
  }
  const result = await requestConnectBridge({
    type: "POST_CONNECT",
    envelope,
    publicationUrl
  });
  if (!result.ok || result.submit?.ok === false) {
    return setFlow({
      phase: "failed",
      flowId,
      message: result.message ?? result.submit?.message ?? "Connection failed."
    });
  }
  await clearAppStateCache();
  return setFlow({ phase: "done", flowId, profile: null });
}
async function maybeAutoConnect(forceAppState = false) {
  if (flow.phase !== "idle") return;
  const stored = await chrome.storage.session.get("autoConnect");
  const lastAttemptAt = stored.autoConnect?.lastAttemptAt ?? 0;
  if (Date.now() - lastAttemptAt < AUTO_CONNECT_COOLDOWN_MS) return;
  await chrome.storage.session.set({ autoConnect: { lastAttemptAt: Date.now() } });
  const state = await requestAppState(forceAppState);
  if (!state.ok || !state.appState) return;
  if (state.appState.connection) return;
  if (!await hasSubstackSession()) return;
  await runConnectFlow({ focusSubstack: false, askPublication: false });
}
async function handlePopupRequest(request) {
  switch (request.type) {
    case "GET_STATUS": {
      void maybeAutoConnect();
      const [substackLoggedIn, app] = await Promise.all([
        hasSubstackSession(),
        requestAppState()
      ]);
      const appHandles = handlesFromAppState(app);
      if (appHandles) crmHandles = appHandles;
      let appState = "unreachable";
      let appProfile = null;
      if (app.ok && app.appState) {
        appState = app.appState.connection ? "connected" : "none";
        appProfile = app.appState.connection?.profile.name ?? app.appState.connection?.profile.handle ?? null;
      } else if (app.needsAuth) {
        appState = "needsAuth";
      }
      return {
        ok: true,
        flow,
        substackLoggedIn,
        appState,
        appProfile,
        appPublicationUrl: app.ok && app.appState ? app.appState.connection?.publicationUrl ?? null : null
      };
    }
    case "START_CONNECT_FLOW":
      return { ok: true, flow: await runConnectFlow() };
    case "connect-from-app":
      return { ok: true, flow: await runConnectFlow() };
    case "APP_PAGE_LOADED":
      void maybeAutoConnect(true);
      return { ok: true };
    case "SUBMIT_PUBLICATION_URL": {
      if (flow.phase !== "asking-publication" || flow.flowId !== request.flowId) {
        return { ok: false, message: "No connection is waiting for a publication URL." };
      }
      pendingPublicationUrl = {
        flowId: request.flowId,
        url: request.publicationUrl
      };
      return { ok: true };
    }
    case "ADD_FEED_PERSON": {
      const handle = request.handle.trim().toLocaleLowerCase("en");
      const name = request.name.trim().replace(/\s+/g, " ").slice(0, 80);
      if (!/^[a-z0-9](?:[a-z0-9_-]{0,62}[a-z0-9])?$/.test(handle)) {
        return { ok: false, message: "Invalid Substack handle." };
      }
      if (!name) {
        return { ok: false, message: "Could not read the author's name." };
      }
      const result = await requestConnectBridge({
        type: "POST_CREATE_PERSON",
        name,
        handle,
        lists: request.lists.slice(0, 20),
        tags: []
      });
      const ok = result.ok && result.submit?.ok !== false;
      const message = result.submit?.message ?? result.message ?? (ok ? "Added." : "Failed.");
      if (ok) {
        await rememberCrmHandle(handle, name, request.lists);
      }
      return {
        ok,
        message,
        alreadyInCrm: !ok && /already/i.test(message),
        memberLists: crmMembers?.get(handle)?.lists ?? []
      };
    }
    case "GET_CRM_STATUS": {
      const normalized = request.handle.trim().toLocaleLowerCase("en");
      if (!crmHandles || !crmMembers) {
        const app = await requestAppState();
        const appHandles = handlesFromAppState(app);
        if (appHandles) crmHandles = appHandles;
      }
      const inCrm = crmHandles?.has(normalized) ?? false;
      const memberLists = crmMembers?.get(normalized)?.lists ?? [];
      if (inCrm) {
        console.log(`[StackedHQ Background] @${normalized} is in CRM with lists:`, memberLists);
      }
      return { ok: true, inCrm, memberLists };
    }
    case "GET_CURRENT_PROFILE": {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      return { ok: true, profile: tab ? detectProfileFromTab(tab) : null };
    }
    case "FETCH_LISTS": {
      const state = await requestAppState();
      return {
        ok: state.ok,
        message: state.message,
        needsAuth: state.needsAuth,
        lists: state.appState?.lists ?? []
      };
    }
    case "CAPTURE_ACTIVITY_BATCH": {
      const count = Array.isArray(
        request.payload?.activityItems
      ) ? request.payload.activityItems.length : 0;
      console.log(`[StackedHQ Activity] Background received ${count} captured items.`);
      const result = await requestViaBridge({
        type: "POST_ACTIVITY_BATCH",
        payload: request.payload
      });
      if (result.ok) {
        console.log(`[StackedHQ Activity] App bridge accepted the captured batch.`);
      } else {
        console.warn(
          `[StackedHQ Activity] App bridge unavailable; scheduled sync remains the fallback. ${result.message ?? ""}`.trim()
        );
      }
      return {
        ok: result.ok,
        message: result.message ?? result.submit?.message,
        captured: result.captured,
        processedItems: result.processedItems,
        newInteractions: result.newInteractions,
        newPeople: result.newPeople,
        updatedPeople: result.updatedPeople
      };
    }
    case "ADD_TO_LISTS": {
      const handle = request.handle.trim().toLocaleLowerCase("en");
      const result = await requestViaBridge({
        type: "POST_CREATE_PERSON",
        name: request.name,
        handle,
        lists: request.lists,
        tags: request.tags
      });
      const ok = result.ok && result.submit?.ok !== false;
      if (ok) await rememberCrmHandle(handle, request.name, request.lists);
      return {
        ok,
        message: result.message ?? result.submit?.message,
        submit: result.submit,
        memberLists: crmMembers?.get(handle)?.lists ?? []
      };
    }
  }
}
chrome.runtime.onMessage.addListener(
  (request, sender, sendResponse) => {
    if (request.type === "CAPTURE_ACTIVITY_BATCH" && !isSubstackPageUrl(sender.url)) {
      sendResponse({ ok: false, message: "Activity capture source was rejected." });
      return;
    }
    void handlePopupRequest(request).then(sendResponse);
    return true;
  }
);
chrome.runtime.onMessageExternal.addListener(
  (request, _sender, sendResponse) => {
    if (request?.type === "ping") {
      sendResponse({ ok: true, installed: true });
      return;
    }
    if (request?.type === "connect-from-app") {
      void runConnectFlow().then(sendResponse);
      return true;
    }
    sendResponse({ ok: false, message: "Unknown request." });
  }
);
async function waitForTabLoad(tabId, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === "complete") return;
    } catch {
      return;
    }
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
}
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason !== "install") return;
  void chrome.tabs.create({ url: `${APP_ORIGINS[0]}/app/companion?installed=1` }).then(async (tab) => {
    if (!tab.id) return;
    await waitForTabLoad(tab.id, 2e4);
    await requestViaBridge({ type: "POST_INSTALL" });
    const state = await requestAppState();
    if (state.ok && state.appState && !state.appState.connection) {
      await runConnectFlow();
    }
  }).catch(() => void 0);
});
void readStoredFlow();
//# sourceMappingURL=background.js.map
