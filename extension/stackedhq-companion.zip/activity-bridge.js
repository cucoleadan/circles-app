"use strict";
(() => {
  // src/activity-bridge.ts
  var MESSAGE_SOURCE = "stackedhq-page-observer";
  var observedActivityBatches = /* @__PURE__ */ new Set();
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const message = event.data;
    if (message?.source !== MESSAGE_SOURCE || message.type !== "ACTIVITY_RESPONSE" || !Array.isArray(message.payload?.activityItems)) return;
    const items = message.payload.activityItems;
    const batchKey = JSON.stringify([
      items.length,
      items[0]?.id ?? items[0]?.item_key ?? null,
      items[items.length - 1]?.id ?? items[items.length - 1]?.item_key ?? null
    ]);
    if (observedActivityBatches.has(batchKey)) {
      console.log(`[StackedHQ Activity] Skipped duplicate batch (${items.length} items).`);
      return;
    }
    observedActivityBatches.add(batchKey);
    if (observedActivityBatches.size > 20) {
      const oldest = observedActivityBatches.values().next().value;
      if (oldest !== void 0) observedActivityBatches.delete(oldest);
    }
    console.log(`[StackedHQ Activity] Forwarding ${items.length} captured items to StackedHQ.`);
    void chrome.runtime.sendMessage({
      type: "CAPTURE_ACTIVITY_BATCH",
      payload: message.payload
    }).then((result) => {
      if (result?.ok) {
        console.log(
          `[StackedHQ Activity] Stored ${result.captured ?? items.length} items; ${result.newInteractions ?? 0} new interactions and ${result.newPeople ?? 0} new people.`
        );
      } else {
        console.warn(
          `[StackedHQ Activity] Live capture was not stored; scheduled sync remains the fallback. ${result?.message ?? ""}`.trim()
        );
      }
    }).catch((error) => {
      console.warn("[StackedHQ Activity] Could not reach the extension background worker; scheduled sync remains the fallback.", error);
    });
  });
})();
//# sourceMappingURL=activity-bridge.js.map
